list_drivers=[["ID001", "Max Verstappen", "Beirut"],["ID002", "Charles Leclerc", "Tripoli"],["ID003", "Lando Norris", "Jdeideh"],["ID004", "Moe Salah", "Beirut"]]

list_allstartcities=["Beirut","Tripoli","Jdeideh"]
dict_nearcities={"Beirut":["Chyah","Dekwaneh","Bourj Hammoud", "Baabda", "Jdeideh","Kfarshima","Antelias",  "Beit Mery", "Brummana", "Ras el Matn",  "Aintoura","Baabdat", "Juniyah"],"Tripoli":["Jbeil","Juniyah","Baskinta", "Aintoura","Bteghrine","Bikfaya","Beit Chabab","Dbayeh", "Antelias", "Baabdat","Brummana"],"Jdeideh":["Chyah","Dekwaneh","Bourj Hammoud", "Dbayeh", "Kfarshima","Antelias",  "Beit Mery", "Brummana", "Bikfaya",  "Aintoura","Baabdat", "Ras el Matn","Beirut","Sen el Fil"]}




def citiesMenu():
  choice_citiesMenu=int(input("1. Show cities\n2. Print neighboring cities\n3. Print Drivers delivering to city\n"))
  if choice_citiesMenu==1:
    viewCities()
  elif choice_citiesMenu==2:
    nearCities()
  elif choice_citiesMenu==3:
    deliveryDrivers()
  else:
    print("invalid input please try again")
    citiesMenu()

def driverMenu():

  choice_driverMenu=int(input("Enter:\n1. To view all the drivers\n2. To add a driver\n3. To go back to main menu\n"))
  if choice_driverMenu==1:
    viewDrivers()
  elif choice_driverMenu==2:
    addDriver()
  elif choice_driverMenu==3:
    firstMenu()
  else:
    print("invalid input please try again")
    driverMenu()











def firstMenu():
  choice_firstMenu=int(input("Hello! Please enter:\n1. To go to the drivers\n2. To go to the cities\n3. To exit the system\n"))
  if choice_firstMenu==1:
    driverMenu()
  elif choice_firstMenu==2:
    citiesMenu()
  elif choice_firstMenu==3:
    return
  else:
    print("invalid input please try again")
    firstMenu()

firstMenu()

