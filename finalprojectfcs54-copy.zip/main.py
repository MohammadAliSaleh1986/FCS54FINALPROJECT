





def firstMenu():
  choice_firstMenu=int(input("Hello! Please enter:\n1. To go to the drivers\n2. To go to the cities\n3. To exit the system\n"))
  if choice_firstMenu==1:
    driverMenu()
  elif choice_firstMenu==2:
    citiesMenu()
  elif choice_firstMenu==3:
    return
  else:
    print("invalid input please try again")
    firstMenu()

firstMenu()

