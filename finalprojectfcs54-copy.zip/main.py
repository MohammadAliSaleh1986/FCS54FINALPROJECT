list_drivers=[["ID001", "Max Verstappen", "Beirut"],["ID002", "Charles Leclerc", "Tripoli"],["ID003", "Lando Norris", "Jdeideh"],["ID004", "Moe Salah", "Beirut"]]

list_allstartcities=["Beirut","Tripoli","Jdeideh"]
dict_nearcities={"Beirut":["Chyah","Dekwaneh","Bourj Hammoud", "Baabda", "Jdeideh","Kfarshima","Antelias",  "Beit Mery", "Brummana", "Ras el Matn",  "Aintoura","Baabdat", "Juniyah"],"Tripoli":["Jbeil","Juniyah","Baskinta", "Aintoura","Bteghrine","Bikfaya","Beit Chabab","Dbayeh", "Antelias", "Baabdat","Brummana"],"Jdeideh":["Chyah","Dekwaneh","Bourj Hammoud", "Dbayeh", "Kfarshima","Antelias",  "Beit Mery", "Brummana", "Bikfaya",  "Aintoura","Baabdat", "Ras el Matn","Beirut","Sen el Fil"]}



def viewDrivers():

  for i in list_drivers:
    print(i)



def addDriver():
  driver_name=input("please enter the name of the driver: ")
  driver_startcity=input("please enter the startcity of the driver: ")
  new_id=""

  for i in list_allstartcities:

    if driver_startcity.lower() == i.lower():
      last_id=list_drivers[len(list_drivers)-1][0]
      pre_id=str(int(last_id[2:])+1)
      if len(pre_id)==1:
        new_id=last_id[0:(len(last_id)-1)]+pre_id
      elif len(str(pre_id))==2:
        new_id=last_id[0:(len(last_id)-2)]+pre_id
      elif len(str(pre_id))>=3:
        new_id=last_id[0:(len(last_id)-3)]+pre_id

      list_drivers.append([new_id,driver_name,driver_startcity])
      break;


  else:
      answer=input("The city is not available,if you want to add it to the database, enter yes,you should do so.")
      if answer.lower()=="yes":
        list_allstartcities.append(driver_startcity)
      last_id=list_drivers[len(list_drivers)-1][0]
      pre_id=str(int(last_id[2:])+1)
      if len(pre_id)==1:
        new_id=last_id[0:(len(last_id)-1)]+pre_id
      elif len(str(pre_id))==2:
        new_id=last_id[0:(len(last_id)-2)]+pre_id
      elif len(str(pre_id))>=3:
        new_id=last_id[0:(len(last_id)-3)]+pre_id

      list_drivers.append([new_id,driver_name,driver_startcity])
  print(list_drivers,list_allstartcities)





def citiesMenu():
  choice_citiesMenu=int(input("1. Show cities\n2. Print neighboring cities\n3. Print Drivers delivering to city\n"))
  if choice_citiesMenu==1:
    viewCities()
  elif choice_citiesMenu==2:
    nearCities()
  elif choice_citiesMenu==3:
    deliveryDrivers()
  else:
    print("invalid input please try again")
    citiesMenu()

def driverMenu():

  choice_driverMenu=int(input("Enter:\n1. To view all the drivers\n2. To add a driver\n3. To go back to main menu\n"))
  if choice_driverMenu==1:
    viewDrivers()
  elif choice_driverMenu==2:
    addDriver()
  elif choice_driverMenu==3:
    firstMenu()
  else:
    print("invalid input please try again")
    driverMenu()











def firstMenu():
  choice_firstMenu=int(input("Hello! Please enter:\n1. To go to the drivers\n2. To go to the cities\n3. To exit the system\n"))
  if choice_firstMenu==1:
    driverMenu()
  elif choice_firstMenu==2:
    citiesMenu()
  elif choice_firstMenu==3:
    return
  else:
    print("invalid input please try again")
    firstMenu()

firstMenu()

